In this code, we've impemented most of the parts of the paper (Cross-View Tracking for Multi-Human 3D Pose Estimation at over 100 FPS). It is still incomplete but the skeleton contains most of the main parts described in the paper. 

To run the code, go to the directory of the modules, and run (python3 main.py)
